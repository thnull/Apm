#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_PATH="/usr/local/bin/apm"

if ! command -v go >/dev/null 2>&1; then
    echo "Error: Go is required but was not found in PATH." >&2
    exit 1
fi

if [[ "$(id -u)" -eq 0 ]]; then
    RUN_ROOT=()
else
    if ! command -v sudo >/dev/null 2>&1; then
        echo "Error: sudo is required to install APM into ${INSTALL_PATH}." >&2
        exit 1
    fi
    RUN_ROOT=(sudo)
fi

TMP_BIN="$(mktemp)"
trap 'rm -f -- "$TMP_BIN"' EXIT

echo "Building APM..."
cd "$ROOT"
go build -o "$TMP_BIN" ./cmd/apm

echo "Installing APM to ${INSTALL_PATH}..."
"${RUN_ROOT[@]}" install -Dm755 "$TMP_BIN" "$INSTALL_PATH"

echo "APM installed successfully."
echo "Run: apm --help"
"$INSTALL_PATH" --help >/dev/null
