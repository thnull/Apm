<?php echo "phplike ok\n";
