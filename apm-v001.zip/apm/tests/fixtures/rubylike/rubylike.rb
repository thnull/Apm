puts 'rubylike ok'
