#!/usr/bin/env perl
print "perllike ok\n";
