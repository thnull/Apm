module example.com/multilike

go 1.23
