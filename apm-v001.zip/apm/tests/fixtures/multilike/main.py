print('multi python')
