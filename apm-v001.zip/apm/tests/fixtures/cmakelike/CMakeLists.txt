cmake_minimum_required(VERSION 3.10)
project(cmakelike C)
add_executable(cmakelike main.c)
