#include <stdio.h>
int main(){puts("cmakelike ok");return 0;}
