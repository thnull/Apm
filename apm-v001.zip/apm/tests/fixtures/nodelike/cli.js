#!/usr/bin/env node
console.log('nodelike ok')
