print("pylike ok")
