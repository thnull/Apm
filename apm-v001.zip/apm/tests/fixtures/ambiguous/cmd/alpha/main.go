package main
import "fmt"
func main(){fmt.Println("alpha ok")}
