module example.com/httpxlike

go 1.23
