#!/usr/bin/env node
console.log('beef node helper')
