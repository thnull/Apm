#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="$ROOT/apm-test-bin"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK" "$BIN"' EXIT
cd "$ROOT"
go build -o "$BIN" ./cmd/apm
APM="$BIN"
P="$WORK/apm"
L="$WORK/bin"
mkdir -p "$L"
run_install(){ "$APM" install --install-path "$P" --link-path "$L" "$@"; }
# httpx-like: primary target and post-commit symlink.
run_install "file://$ROOT/tests/fixtures/httpxlike"
TARGET="$P/packages/httpxlike/bin/httpxlike"
LINK="$L/httpxlike"
test -x "$TARGET"
test -L "$LINK"
[ "$(readlink -f "$LINK")" = "$(readlink -f "$TARGET")" ]
! [[ "$(readlink "$LINK")" == *".installing"* ]]
! test -e "$P/packages/httpxlike.installing"
[ "$("$LINK")" = "httpxlike ok" ]
# Transactional update: a broken new source must not destroy the installed version.
cp "$ROOT/tests/fixtures/httpxlike/cmd/httpxlike/main.go" "$WORK/httpx-main.go"
printf "%s\n" "package main" "func broken( {}" > "$ROOT/tests/fixtures/httpxlike/cmd/httpxlike/main.go"
if "$APM" update --install-path "$P" --link-path "$L" httpxlike; then
  echo "broken update unexpectedly succeeded" >&2; exit 1
fi
cp "$WORK/httpx-main.go" "$ROOT/tests/fixtures/httpxlike/cmd/httpxlike/main.go"
test ! -e "$P/packages/httpxlike.installing"
[ "$("$LINK")" = "httpxlike ok" ]
[ "$(readlink -f "$LINK")" = "$(readlink -f "$P/packages/httpxlike/bin/httpxlike")" ]
# Python isolated environment and executable.
run_install "file://$ROOT/tests/fixtures/pylike"
test -x "$P/packages/pylike/environment/python/venv/bin/python"
test -x "$P/packages/pylike/bin/pylike"
[ "$("$L/pylike")" = "pylike ok" ]
[ "$(readlink -f "$L/pylike")" = "$(readlink -f "$P/packages/pylike/bin/pylike")" ]
# Realistic sqlmap layout: repo name and sqlmap.py match, with no venv activation.
run_install "file://$ROOT/tests/fixtures/sqlmap"
test -x "$P/packages/sqlmap/bin/sqlmap"
[ "$($L/sqlmap)" = "sqlmap ok" ]
# Node.
run_install "file://$ROOT/tests/fixtures/nodelike"
test -x "$P/packages/nodelike/bin/nodelike"
[ "$("$L/nodelike")" = "nodelike ok" ]
# CMake.
run_install "file://$ROOT/tests/fixtures/cmakelike"
test -x "$P/packages/cmakelike/bin/cmakelike"
[ "$("$L/cmakelike")" = "cmakelike ok" ]
# Ruby/PHP/Perl script providers.
run_install "file://$ROOT/tests/fixtures/rubylike"
[ "$("$L/rubylike")" = "rubylike ok" ]
# BeEF-shaped multi-runtime repository: Ruby executable has no .rb suffix,
# while Node metadata is also present. Ruby target resolution must select beef.
run_install "file://$ROOT/tests/fixtures/beeflike"
test -x "$P/packages/beeflike/bin/beef"
test -d "$P/packages/beeflike/environment/ruby/bundle"
[ "$($L/beef)" = "beef ok" ]

run_install "file://$ROOT/tests/fixtures/phplike"
[ "$("$L/phplike")" = "phplike ok" ]
run_install "file://$ROOT/tests/fixtures/perllike"
[ "$("$L/perllike")" = "perllike ok" ]
# Multi ecosystem creates both envs.
run_install --multivenv "file://$ROOT/tests/fixtures/multilike"
test -d "$P/packages/multilike/environment/go"
test -d "$P/packages/multilike/environment/python"
"$APM" env create multilike --go --python --install-path "$P" --link-path "$L"
test -d "$P/packages/multilike/environment/go"
# Ambiguous Go must fail instead of picking a random main.go.
if run_install "file://$ROOT/tests/fixtures/ambiguous"; then
  echo "ambiguous project unexpectedly installed" >&2; exit 1
fi
# Debug works after URL too.
"$APM" install --install-path "$P" --link-path "$L" "file://$ROOT/tests/fixtures/httpxlike" --debug >/tmp/apm-debug-out 2>/tmp/apm-debug-err
# CLI flag parser accepts --debug after URL; verify diagnostic output exists.
grep -q '\[debug\]' /tmp/apm-debug-err
# Update and symlink remains final path.
"$APM" update --install-path "$P" --link-path "$L" httpxlike
test -L "$L/httpxlike"
[ "$(readlink -f "$L/httpxlike")" = "$(readlink -f "$P/packages/httpxlike/bin/httpxlike")" ]
! [[ "$(readlink "$L/httpxlike")" == *".installing"* ]]
# Manual target selection on an otherwise ambiguous repository.
run_install --build-system node --target ./alpha.js --executable alpha-tool "file://$ROOT/tests/fixtures/nodeambiguous"
test -x "$P/packages/nodeambiguous/bin/alpha-tool"
test -L "$L/alpha-tool"
[ "$("$L/alpha-tool")" = "alpha node ok" ]
# Configure an installed tool to switch executable target/name. The old public
# link must be removed and the configuration must survive a subsequent update.
"$APM" configure nodeambiguous --install-path "$P" --link-path "$L" --build-system node --target ./beta.js --executable beta-tool
! test -e "$L/alpha-tool"
test -x "$P/packages/nodeambiguous/bin/beta-tool"
test -L "$L/beta-tool"
[ "$("$L/beta-tool")" = "beta node ok" ]
test -f "$P/packages/nodeambiguous/apm.config.json"
"$APM" update --install-path "$P" --link-path "$L" nodeambiguous
test -L "$L/beta-tool"
! test -e "$L/alpha-tool"
[ "$("$L/beta-tool")" = "beta node ok" ]
# CLI manual recipe overrides a conflicting repository apm.json.
mkdir -p "$WORK/recipeoverride"
cat > "$WORK/recipeoverride/package.json" <<'EOF2'
{"name":"recipeoverride","version":"1.0.0","bin":{"one":"./one.js","two":"./two.js"}}
EOF2
printf '%s\n' "console.log('one')" > "$WORK/recipeoverride/one.js"
printf '%s\n' "console.log('two')" > "$WORK/recipeoverride/two.js"
cat > "$WORK/recipeoverride/apm.json" <<'EOF2'
{"build":{"system":"node","target":"./one.js"},"executables":["one"]}
EOF2
run_install --build-system node --target ./two.js --executable two "file://$WORK/recipeoverride"
test -x "$P/packages/recipeoverride/bin/two"
[ "$("$L/two")" = "two" ]
! test -e "$P/packages/recipeoverride/bin/one"
echo "CONFIGURE/MANUAL TARGET TESTS PASSED"
# Multiple explicit executables can be configured in one command.
"$APM" configure nodeambiguous --install-path "$P" --link-path "$L" --build-system node \
  --target ./alpha.js --executable alpha2 \
  --target ./beta.js --executable beta2
test -x "$P/packages/nodeambiguous/bin/alpha2"
test -x "$P/packages/nodeambiguous/bin/beta2"
[ "$("$L/alpha2")" = "alpha node ok" ]
[ "$("$L/beta2")" = "beta node ok" ]
! test -e "$L/beta-tool"
echo "ALL INTEGRATION TESTS PASSED"
