package main

import (
	"fmt"
	"github.com/apm-project/apm/internal/config"
	"github.com/apm-project/apm/internal/configure"
	"github.com/apm-project/apm/internal/debug"
	"github.com/apm-project/apm/internal/detect"
	"github.com/apm-project/apm/internal/env"
	"github.com/apm-project/apm/internal/install"
	"github.com/apm-project/apm/internal/model"
	"github.com/apm-project/apm/internal/resolve"
	"os"
	"path/filepath"
)

type options struct {
	debug, multi bool
	root, link   string
	envs         []model.Ecosystem
	buildSystem  string
	targets      []string
	executables  []string
	pos          []string
}

func parse(a []string) (options, error) {
	o := options{root: "/opt/apm", link: "/usr/local/bin"}
	for i := 0; i < len(a); i++ {
		switch a[i] {
		case "--debug":
			o.debug = true
		case "--multivenv":
			o.multi = true
		case "--install-path":
			if i+1 >= len(a) {
				return o, fmt.Errorf("--install-path requires a value")
			}
			i++
			o.root = a[i]
		case "--go":
			o.envs = append(o.envs, model.Go)
		case "--rust":
			o.envs = append(o.envs, model.Rust)
		case "--python":
			o.envs = append(o.envs, model.Python)
		case "--ruby":
			o.envs = append(o.envs, model.Ruby)
		case "--node":
			o.envs = append(o.envs, model.Node)
		case "--java":
			o.envs = append(o.envs, model.Java)
		case "--c":
			o.envs = append(o.envs, model.C)
		case "--cpp":
			o.envs = append(o.envs, model.Cpp)
		case "--dotnet":
			o.envs = append(o.envs, model.DotNet)
		case "--php":
			o.envs = append(o.envs, model.PHP)
		case "--perl":
			o.envs = append(o.envs, model.Perl)
		case "--build-system":
			if i+1 >= len(a) {
				return o, fmt.Errorf("--build-system requires a value")
			}
			i++
			o.buildSystem = a[i]
		case "--target":
			if i+1 >= len(a) {
				return o, fmt.Errorf("--target requires a value")
			}
			i++
			o.targets = append(o.targets, a[i])
		case "--executable":
			if i+1 >= len(a) {
				return o, fmt.Errorf("--executable requires a value")
			}
			i++
			o.executables = append(o.executables, a[i])
		case "--link-path":
			if i+1 >= len(a) {
				return o, fmt.Errorf("--link-path requires a value")
			}
			i++
			o.link = a[i]
		case "-h", "--help":
			usage()
			os.Exit(0)
		default:
			if len(a[i:]) > 0 {
				o.pos = append(o.pos, a[i])
			}
		}
	}
	return o, nil
}
func usage() {
	fmt.Fprintln(os.Stderr, `APM - Advanced Package Manager

Usage:
  apm install [flags] <url>
  apm update [flags] <tool>
  apm env create <tool> [ecosystem flags]
  apm configure <tool> --build-system go --target ./cmd/tool --executable tool

Flags:
  --debug                 show detailed decisions and commands
  --multivenv             prepare environments for all detected ecosystems
  --install-path PATH     package root (default /opt/apm)
  --link-path PATH        command symlink directory (default /usr/local/bin)
  --build-system SYSTEM   manual build system for configure/install
  --target PATH            manual source target; repeatable
  --executable NAME        launcher name paired with --target; repeatable
  --go/--rust/...         select ecosystem for env create
  -h, --help              show help`)
}
func main() {
	o, e := parse(os.Args[1:])
	if e != nil {
		fmt.Fprintln(os.Stderr, "apm:", e)
		os.Exit(2)
	}
	if len(o.pos) < 2 {
		usage()
		os.Exit(2)
	}
	c := config.Defaults(o.root, o.link)
	var err error
	switch o.pos[0] {
	case "install":
		if len(o.pos) < 2 {
			err = fmt.Errorf("install requires a repository URL")
		} else {
			var recipe *resolve.Recipe
			if len(o.targets) > 0 || len(o.executables) > 0 || o.buildSystem != "" {
				if len(o.targets) != len(o.executables) || len(o.targets) == 0 {
					err = fmt.Errorf("manual install configuration requires matching --target and --executable values")
				} else {
					recipe = &resolve.Recipe{}
					recipe.Build.System = o.buildSystem
					for i := range o.targets {
						recipe.Targets = append(recipe.Targets, resolve.RecipeTarget{Target: o.targets[i], Executable: o.executables[i]})
					}
				}
			}
			if err == nil {
				err = install.Install(c, o.pos[1], o.multi, o.debug, recipe)
			}
		}
	case "configure":
		if len(o.pos) < 2 {
			err = fmt.Errorf("configure requires an installed tool name")
		} else if len(o.targets) != len(o.executables) || len(o.targets) == 0 {
			err = fmt.Errorf("configure requires matching --target and --executable values")
		} else {
			spec := configure.Spec{BuildSystem: o.buildSystem}
			for i := range o.targets {
				spec.Targets = append(spec.Targets, resolve.RecipeTarget{Target: o.targets[i], Executable: o.executables[i]})
			}
			err = configure.Apply(c, o.pos[1], spec, o.debug)
		}
	case "update":
		if len(o.pos) < 2 {
			err = fmt.Errorf("update requires a tool name")
		} else {
			err = install.Update(c, o.pos[1], o.debug)
		}
	case "env":
		if len(o.pos) < 3 || o.pos[1] != "create" {
			err = fmt.Errorf("usage: apm env create <tool> [ecosystem flags]")
		} else {
			name := o.pos[2]
			packageRoot := config.Package(c.Root, name)
			if _, e := os.Stat(packageRoot); e != nil {
				err = fmt.Errorf("tool is not installed: %s", name)
			} else {
				var es = o.envs
				if len(es) == 0 {
					d := detect.Detect(filepath.Join(packageRoot, "source"), name, &debug.Logger{Enabled: o.debug, W: os.Stderr})
					for _, x := range d {
						es = append(es, x.Ecosystem)
					}
				}
				err = env.Prepare(packageRoot, es, &debug.Logger{Enabled: o.debug, W: os.Stderr})
			}
		}
	default:
		err = fmt.Errorf("unknown command: %s", o.pos[0])
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "apm:", err)
		os.Exit(1)
	}
}
