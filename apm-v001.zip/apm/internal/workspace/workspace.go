package workspace

import (
	"fmt"
	"io"
	"net/url"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"strings"
)

func Ensure(root string) error { return os.MkdirAll(filepath.Join(root, "packages"), 0755) }
func Clone(url, dst string) error {
	if strings.HasPrefix(url, "file://") {
		return copyTree(strings.TrimPrefix(url, "file://"), dst)
	}
	c := exec.Command("git", "clone", "--depth", "1", url, dst)
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	return c.Run()
}
func copyTree(src, dst string) error {
	return filepath.Walk(src, func(p string, i os.FileInfo, e error) error {
		if e != nil {
			return e
		}
		rel, _ := filepath.Rel(src, p)
		if rel == "." {
			return os.MkdirAll(dst, 0755)
		}
		if rel == ".git" || strings.HasPrefix(rel, ".git"+string(os.PathSeparator)) {
			if i.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		q := filepath.Join(dst, rel)
		if i.IsDir() {
			return os.MkdirAll(q, i.Mode())
		}
		in, er := os.Open(p)
		if er != nil {
			return er
		}
		defer in.Close()
		out, er := os.OpenFile(q, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, i.Mode())
		if er != nil {
			return er
		}
		defer out.Close()
		_, er = io.Copy(out, in)
		return er
	})
}
func Name(raw string) string {
	name := ""
	if u, err := url.Parse(raw); err == nil && u.Path != "" {
		name = path.Base(strings.TrimRight(u.Path, "/"))
	} else {
		name = path.Base(strings.TrimRight(raw, "/"))
	}
	name = strings.TrimSuffix(name, ".git")
	if name == "" || name == "." || name == ".." {
		return "tool"
	}
	// Package names become filesystem path components. Replace anything
	// outside a conservative portable set instead of allowing separators or
	// control characters to influence the package path.
	var b strings.Builder
	for _, r := range name {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '-' || r == '_' || r == '.' {
			b.WriteRune(r)
		} else {
			b.WriteByte('_')
		}
	}
	name = strings.Trim(b.String(), ".")
	if name == "" || name == "." || name == ".." {
		return "tool"
	}
	return name
}

var _ = fmt.Sprintf
