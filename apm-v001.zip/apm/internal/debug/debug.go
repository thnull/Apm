package debug

import (
	"fmt"
	"io"
)

type Logger struct {
	Enabled bool
	W       io.Writer
}

func (l *Logger) Printf(f string, a ...any) {
	if l != nil && l.Enabled {
		fmt.Fprintf(l.W, "[debug] "+f+"\n", a...)
	}
}
