package configure

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/apm-project/apm/internal/config"
	"github.com/apm-project/apm/internal/debug"
	"github.com/apm-project/apm/internal/detect"
	"github.com/apm-project/apm/internal/install"
	"github.com/apm-project/apm/internal/model"
	"github.com/apm-project/apm/internal/resolve"
)

type Spec struct {
	BuildSystem string
	Targets     []resolve.RecipeTarget
}

func Apply(c config.Config, name string, spec Spec, dbg bool) error {
	if len(spec.Targets) == 0 {
		return fmt.Errorf("at least one --target/--executable pair is required")
	}
	pkg := config.Package(c.Root, name)
	source := filepath.Join(pkg, "source")
	if st, err := os.Stat(pkg); err != nil || !st.IsDir() {
		return fmt.Errorf("tool is not installed: %s", name)
	}
	d := detect.Detect(source, name, &debug.Logger{Enabled: dbg, W: os.Stderr})
	if len(d) == 0 {
		return fmt.Errorf("no supported build system detected in %s", name)
	}
	system := spec.BuildSystem
	if system == "" || system == "auto" {
		if len(d) != 1 {
			return fmt.Errorf("multiple build systems detected; specify --build-system")
		}
		system = string(d[0].Ecosystem)
	}
	if !supported(system) {
		return fmt.Errorf("unsupported build system: %s", system)
	}
	recipe := &resolve.Recipe{}
	recipe.Build.System = system
	recipe.Targets = append([]resolve.RecipeTarget(nil), spec.Targets...)
	for _, t := range recipe.Targets {
		if t.Executable == "" || t.Target == "" {
			return fmt.Errorf("each target requires both executable and target")
		}
		if filepath.IsAbs(t.Target) {
			return fmt.Errorf("target must be relative to source: %s", t.Target)
		}
		path := filepath.Join(source, t.Target)
		if _, err := os.Stat(path); err != nil {
			return fmt.Errorf("target does not exist: %s", t.Target)
		}
	}
	if _, err := resolve.ResolveWithRecipe(source, name, d, &debug.Logger{Enabled: dbg, W: os.Stderr}, recipe); err != nil {
		return fmt.Errorf("invalid configuration: %w", err)
	}
	b, err := json.MarshalIndent(recipe, "", "  ")
	if err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(pkg, "apm.config.json"), b, 0644); err != nil {
		return err
	}
	return install.Update(c, name, dbg)
}

func supported(s string) bool {
	switch model.Ecosystem(s) {
	case model.Go, model.Rust, model.Python, model.Ruby, model.Java, model.C, model.Cpp, model.Node, model.DotNet, model.PHP, model.Perl:
		return true
	default:
		return false
	}
}
