package env

import (
	"fmt"
	"github.com/apm-project/apm/internal/debug"
	"github.com/apm-project/apm/internal/model"
	"os"
	"os/exec"
	"path/filepath"
)

func Prepare(root string, es []model.Ecosystem, l *debug.Logger) error {
	for _, e := range es {
		p := filepath.Join(root, "environment", string(e))
		if err := os.MkdirAll(p, 0755); err != nil {
			return err
		}
		switch e {
		case model.Python:
			if _, err := exec.LookPath("python3"); err != nil {
				return fmt.Errorf("python3 is required")
			}
			if err := os.MkdirAll(filepath.Join(p, "pip-cache"), 0755); err != nil {
				return err
			}
			v := filepath.Join(p, "venv")
			if _, err := os.Stat(filepath.Join(v, "bin", "python")); os.IsNotExist(err) {
				c := exec.Command("python3", "-m", "venv", v)
				c.Stdout = os.Stdout
				c.Stderr = os.Stderr
				if err := c.Run(); err != nil {
					return fmt.Errorf("python venv: %w", err)
				}
			}
		case model.Go:
			for _, d := range []string{"gocache", "gomodcache", "gopath"} {
				if err := os.MkdirAll(filepath.Join(p, d), 0755); err != nil {
					return err
				}
			}
		case model.Rust:
			for _, d := range []string{"cargo-home", "target"} {
				if err := os.MkdirAll(filepath.Join(p, d), 0755); err != nil {
					return err
				}
			}
		case model.Node:
			if err := os.MkdirAll(filepath.Join(p, "prefix"), 0755); err != nil {
				return err
			}
		case model.Ruby:
			if err := os.MkdirAll(filepath.Join(p, "bundle"), 0755); err != nil {
				return err
			}
		case model.Java:
			for _, d := range []string{"m2", "gradle"} {
				if err := os.MkdirAll(filepath.Join(p, d), 0755); err != nil {
					return err
				}
			}
		default:
			if err := os.MkdirAll(filepath.Join(p, "deps"), 0755); err != nil {
				return err
			}
		}
		l.Printf("prepared %s environment: %s", e, p)
	}
	return nil
}
func Env(root string, e model.Ecosystem) []string {
	p := filepath.Join(root, "environment", string(e))
	x := os.Environ()
	switch e {
	case model.Go:
		// GOCACHE is a content-addressed compiler cache and does not carry
		// project dependency state, so it is safe (and much faster) to share
		// between packages. Module/download state remains isolated below each
		// package via GOMODCACHE and GOPATH.
		apmRoot := filepath.Dir(filepath.Dir(root))
		sharedCache := filepath.Join(apmRoot, "cache", "go-build")
		_ = os.MkdirAll(sharedCache, 0755)
		x = append(x, "GOCACHE="+sharedCache, "GOMODCACHE="+filepath.Join(p, "gomodcache"), "GOPATH="+filepath.Join(p, "gopath"))
	case model.Rust:
		x = append(x, "CARGO_HOME="+filepath.Join(p, "cargo-home"), "CARGO_TARGET_DIR="+filepath.Join(p, "target"))
	case model.Node:
		_ = os.MkdirAll(filepath.Join(p, "cache"), 0755)
		x = append(x, "npm_config_prefix="+filepath.Join(p, "prefix"), "npm_config_cache="+filepath.Join(p, "cache"), "NODE_PATH="+filepath.Join(p, "prefix", "node_modules"))
	case model.Ruby:
		x = append(x, "BUNDLE_PATH="+filepath.Join(p, "bundle"), "BUNDLE_BIN="+filepath.Join(p, "bundle", "bin"), "BUNDLE_GEMFILE="+filepath.Join(root, "source", "Gemfile"))
	case model.Java:
		x = append(x, "MAVEN_USER_HOME="+filepath.Join(p, "m2"), "GRADLE_USER_HOME="+filepath.Join(p, "gradle"))
	case model.PHP:
		x = append(x, "COMPOSER_CACHE_DIR="+filepath.Join(p, "composer-cache"))
	case model.Perl:
		x = append(x, "PERL_CPANM_HOME="+filepath.Join(p, "cpanm-home"))
	}
	return x
}
func PythonBin(root string) string {
	return filepath.Join(root, "environment", "python", "venv", "bin", "python")
}
