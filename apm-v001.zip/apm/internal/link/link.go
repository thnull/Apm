package link

import (
	"fmt"
	"os"
	"path/filepath"
)

func Link(dir, name, target string) error {
	if name == "" || name == "." || name == ".." || filepath.Base(name) != name || filepath.IsAbs(name) {
		return fmt.Errorf("invalid link name: %q", name)
	}
	target, err := filepath.Abs(target)
	if err != nil {
		return err
	}
	if _, err = os.Stat(target); err != nil {
		return fmt.Errorf("link target does not exist: %s", target)
	}
	if err = os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	p := filepath.Join(dir, name)
	tmp := p + ".new"
	_ = os.Remove(tmp)
	if err = os.Symlink(target, tmp); err != nil {
		return err
	}
	if err = os.Rename(tmp, p); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func ReadTarget(dir, name string) (string, error) { return os.Readlink(filepath.Join(dir, name)) }
