package link

import (
	"os"
	"path/filepath"
	"testing"
)

func TestLinkNeverPointsToInstallingWhenTargetIsFinal(t *testing.T) {
	d := t.TempDir()
	target := filepath.Join(d, "packages", "tool", "bin", "tool")
	if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(target, []byte("ok"), 0755); err != nil {
		t.Fatal(err)
	}
	ld := filepath.Join(d, "bin")
	if err := Link(ld, "tool", target); err != nil {
		t.Fatal(err)
	}
	got, err := ReadTarget(ld, "tool")
	if err != nil {
		t.Fatal(err)
	}
	if got != target {
		t.Fatalf("target=%q want=%q", got, target)
	}
}

func TestRejectsPathTraversalName(t *testing.T) {
	d := t.TempDir()
	target := filepath.Join(d, "target")
	if err := os.WriteFile(target, []byte("x"), 0755); err != nil {
		t.Fatal(err)
	}
	if err := Link(d, "../escape", target); err == nil {
		t.Fatal("expected invalid link name")
	}
}
