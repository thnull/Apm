package model

// Ecosystem identifies a language/runtime family. Toolchains themselves are
// intentionally treated as system prerequisites; dependency state lives in
// the package environment.
type Ecosystem string

const (
	Go     Ecosystem = "go"
	Rust   Ecosystem = "rust"
	Python Ecosystem = "python"
	Ruby   Ecosystem = "ruby"
	Java   Ecosystem = "java"
	C      Ecosystem = "c"
	Cpp    Ecosystem = "cpp"
	Node   Ecosystem = "node"
	DotNet Ecosystem = "dotnet"
	PHP    Ecosystem = "php"
	Perl   Ecosystem = "perl"
)

type Detection struct {
	Ecosystem Ecosystem
	Score     int
	Evidence  []string
}
type Target struct {
	Name, Path, Kind string
	Ecosystem        Ecosystem
	Score            int
}
type Artifact struct{ Name, Path string }
