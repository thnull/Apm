package resolve

import (
	"github.com/apm-project/apm/internal/debug"
	"github.com/apm-project/apm/internal/model"
	"os"
	"path/filepath"
	"testing"
)

func write(t *testing.T, p, s string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(p), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(p, []byte(s), 0644); err != nil {
		t.Fatal(err)
	}
}
func TestGoPrefersProjectNamedCommand(t *testing.T) {
	d := t.TempDir()
	write(t, filepath.Join(d, "go.mod"), "module example.com/httpx\ngo 1.23\n")
	write(t, filepath.Join(d, "cmd", "httpx", "main.go"), "package main\nfunc main(){}\n")
	write(t, filepath.Join(d, "cmd", "functional-test", "main.go"), "package main\nfunc main(){}\n")
	ts, e := Resolve(d, "httpx", []model.Detection{{Ecosystem: model.Go, Score: 100}}, &debug.Logger{})
	if e != nil {
		t.Fatal(e)
	}
	if len(ts) != 1 || ts[0].Name != "httpx" {
		t.Fatalf("targets=%+v", ts)
	}
}
func TestAmbiguousFails(t *testing.T) {
	d := t.TempDir()
	write(t, filepath.Join(d, "go.mod"), "module example.com/x\ngo 1.23\n")
	write(t, filepath.Join(d, "cmd", "a", "main.go"), "package main\nfunc main(){}\n")
	write(t, filepath.Join(d, "cmd", "b", "main.go"), "package main\nfunc main(){}\n")
	if _, e := Resolve(d, "x", []model.Detection{{Ecosystem: model.Go, Score: 100}}, &debug.Logger{}); e == nil {
		t.Fatal("expected ambiguity error")
	}
}

func TestNodeBinCannotEscapeSource(t *testing.T) {
	d := t.TempDir()
	write(t, filepath.Join(d, "package.json"), `{"bin":"../../outside.js"}`)
	if _, err := Resolve(d, "evilnode", []model.Detection{{Ecosystem: model.Node, Score: 100}}, &debug.Logger{}); err == nil {
		t.Fatal("expected source-tree escape to be rejected")
	}
}
