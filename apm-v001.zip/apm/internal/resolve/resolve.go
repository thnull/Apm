package resolve

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/apm-project/apm/internal/debug"
	"github.com/apm-project/apm/internal/model"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
)

type Recipe struct {
	Build struct {
		System string `json:"system"`
		Target string `json:"target"`
	} `json:"build"`
	Executables []string       `json:"executables"`
	Targets     []RecipeTarget `json:"targets"`
}

type RecipeTarget struct {
	Executable string `json:"executable"`
	Target     string `json:"target"`
}

func Load(root string) (*Recipe, error) {
	b, e := os.ReadFile(filepath.Join(root, "apm.json"))
	if os.IsNotExist(e) {
		return nil, nil
	}
	if e != nil {
		return nil, e
	}
	var r Recipe
	if e = json.Unmarshal(b, &r); e != nil {
		return nil, e
	}
	return &r, nil
}

func ResolveWithRecipe(root, name string, d []model.Detection, l *debug.Logger, recipe *Recipe) ([]model.Target, error) {
	return resolveWithRecipe(root, name, d, l, recipe)
}

func Resolve(root, name string, d []model.Detection, l *debug.Logger) ([]model.Target, error) {
	r, e := Load(root)
	if e != nil {
		return nil, e
	}
	return resolveWithRecipe(root, name, d, l, r)
}

func resolveWithRecipe(root, name string, d []model.Detection, l *debug.Logger, r *Recipe) ([]model.Target, error) {
	if r != nil && r.Build.System != "" {
		var f []model.Detection
		for _, x := range d {
			if string(x.Ecosystem) == r.Build.System {
				f = append(f, x)
			}
		}
		if len(f) == 0 {
			return nil, fmt.Errorf("apm.json selects unsupported build system: %s", r.Build.System)
		}
		d = f
	}

	// Explicit target mappings are authoritative. This is the escape hatch for
	// repositories whose layout cannot be inferred safely. The target path is
	// still validated against the checkout before it reaches a provider.
	if r != nil && len(r.Targets) > 0 {
		if len(d) == 0 {
			return nil, errors.New("apm.json has explicit targets but no detected build system")
		}
		eco := d[0].Ecosystem
		var out []model.Target
		for _, rt := range r.Targets {
			if rt.Executable == "" || rt.Target == "" {
				return nil, errors.New("apm.json targets require executable and target")
			}
			if err := validateExecutableName(rt.Executable); err != nil {
				return nil, err
			}
			p := rt.Target
			if !filepath.IsAbs(p) {
				p = filepath.Join(root, p)
			}
			out = append(out, model.Target{Name: rt.Executable, Ecosystem: eco, Path: p, Kind: "explicit", Score: 10000})
		}
		return validateAndLog(root, out, l)
	}

	var all []model.Target
	for _, x := range d {
		switch x.Ecosystem {
		case model.Go:
			all = append(all, goTargets(root)...)
		case model.Rust:
			all = append(all, rustTargets(root)...)
		case model.Python:
			all = append(all, pythonTargets(root, name)...)
		case model.Node:
			all = append(all, nodeTargets(root, name)...)
		case model.Ruby:
			all = append(all, rubyTargets(root, name)...)
		case model.Java:
			all = append(all, model.Target{Name: name, Ecosystem: x.Ecosystem, Path: root, Kind: "jvm-project", Score: 70})
		case model.C, model.Cpp:
			all = append(all, cTargets(root, name, x.Ecosystem)...)
		case model.PHP:
			all = append(all, scriptTargets(root, x.Ecosystem, "*.php")...)
		case model.Perl:
			all = append(all, scriptTargets(root, x.Ecosystem, "*.pl")...)
		}
	}
	if r != nil && r.Build.Target != "" {
		for i := range all {
			if sameTarget(root, all[i].Path, r.Build.Target) {
				all[i].Score += 1000
			}
		}
	}
	if r != nil && len(r.Executables) > 0 {
		var f []model.Target
		for _, n := range r.Executables {
			if err := validateExecutableName(n); err != nil {
				return nil, err
			}
			for _, t := range all {
				if t.Name == n {
					f = append(f, t)
				}
			}
		}
		all = f
	}
	if len(all) == 0 {
		return nil, errors.New("no executable target detected")
	}
	// A single build target override is also authoritative when auto-detection
	// found multiple candidates. Re-label it when an explicit executable name
	// was supplied so the launcher name does not have to equal the source name.
	if r != nil && r.Build.Target != "" {
		var matched []model.Target
		for _, t := range all {
			if sameTarget(root, t.Path, r.Build.Target) {
				matched = append(matched, t)
			}
		}
		if len(matched) == 1 {
			all = matched
		} else if len(matched) > 1 {
			return nil, errors.New("apm.json target matches multiple executable targets")
		}
	}
	if len(all) == 1 {
		return validateAndLog(root, all, l)
	}
	var named []model.Target
	for _, t := range all {
		if t.Name == name {
			named = append(named, t)
		}
	}
	if len(named) == 1 {
		return validateAndLog(root, named, l)
	}
	return nil, fmt.Errorf("multiple executable targets detected; use `apm configure %s` or apm.json to select the intended target", name)
}

func validateExecutableName(n string) error {
	if n == "" || n == "." || n == ".." || filepath.Base(n) != n || filepath.IsAbs(n) {
		return fmt.Errorf("invalid executable name: %q", n)
	}
	return nil
}

func sameTarget(root, candidate, configured string) bool {
	p := configured
	if !filepath.IsAbs(p) {
		p = filepath.Join(root, p)
	}
	a, ea := filepath.Abs(candidate)
	b, eb := filepath.Abs(p)
	return ea == nil && eb == nil && filepath.Clean(a) == filepath.Clean(b)
}

func validateAndLog(root string, all []model.Target, l *debug.Logger) ([]model.Target, error) {
	rootAbs, err := filepath.Abs(root)
	if err != nil {
		return nil, err
	}
	for _, t := range all {
		if err := validateExecutableName(t.Name); err != nil {
			return nil, err
		}
		pAbs, err := filepath.Abs(t.Path)
		if err != nil {
			return nil, err
		}
		rel, err := filepath.Rel(rootAbs, pAbs)
		if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return nil, fmt.Errorf("target %q escapes source tree: %s", t.Name, t.Path)
		}
		l.Printf("target %-18s ecosystem=%s kind=%s path=%s", t.Name, t.Ecosystem, t.Kind, t.Path)
	}
	return all, nil
}

func goTargets(root string) []model.Target {
	c := exec.Command("go", "list", "-f", "{{.ImportPath}}|{{.Name}}|{{.Dir}}", "./...")
	c.Dir = root
	b, e := c.Output()
	if e != nil {
		return nil
	}
	var o []model.Target
	s := bufio.NewScanner(strings.NewReader(string(b)))
	for s.Scan() {
		p := strings.SplitN(s.Text(), "|", 3)
		if len(p) != 3 || p[1] != "main" {
			continue
		}
		name := filepath.Base(p[0])
		o = append(o, model.Target{Name: name, Ecosystem: model.Go, Path: p[2], Kind: "go-main", Score: 100})
	}
	return o
}
func rustTargets(root string) []model.Target {
	b, e := os.ReadFile(filepath.Join(root, "Cargo.toml"))
	if e != nil {
		return nil
	}
	re := regexp.MustCompile(`(?m)^name\s*=\s*["']([^"']+)["']`)
	m := re.FindStringSubmatch(string(b))
	if len(m) < 2 {
		return nil
	}
	return []model.Target{{Name: m[1], Ecosystem: model.Rust, Path: root, Kind: "cargo-package", Score: 100}}
}
func pythonTargets(root, name string) []model.Target {
	b, e := os.ReadFile(filepath.Join(root, "pyproject.toml"))
	if e == nil {
		re := regexp.MustCompile(`(?m)^\s*([A-Za-z0-9_.-]+)\s*=\s*[{]?[^\n]*`)
		if i := strings.Index(string(b), "[project.scripts]"); i >= 0 {
			part := string(b)[i:]
			if j := strings.Index(part, "\n["); j > 0 {
				part = part[:j]
			}
			if m := re.FindStringSubmatch(part); len(m) > 1 {
				return []model.Target{{Name: m[1], Ecosystem: model.Python, Path: root, Kind: "python-console-script", Score: 100}}
			}
		}
	}
	for _, candidate := range []string{name + ".py", "main.py"} {
		p := filepath.Join(root, candidate)
		if st, e := os.Stat(p); e == nil && !st.IsDir() {
			return []model.Target{{Name: name, Ecosystem: model.Python, Path: p, Kind: "python-script", Score: 85}}
		}
	}
	if m, _ := filepath.Glob(filepath.Join(root, "*.py")); len(m) == 1 && strings.TrimSuffix(filepath.Base(m[0]), ".py") == name {
		return []model.Target{{Name: name, Ecosystem: model.Python, Path: m[0], Kind: "python-script", Score: 80}}
	}
	return []model.Target{{Name: name, Ecosystem: model.Python, Path: root, Kind: "python-project", Score: 70}}
}
func nodeTargets(root, name string) []model.Target {
	b, e := os.ReadFile(filepath.Join(root, "package.json"))
	if e != nil {
		return nil
	}
	var p struct {
		Bin any `json:"bin"`
	}
	if json.Unmarshal(b, &p) != nil {
		return nil
	}
	switch x := p.Bin.(type) {
	case string:
		return []model.Target{{Name: name, Ecosystem: model.Node, Path: filepath.Join(root, x), Kind: "node-bin", Score: 100}}
	case map[string]any:
		var o []model.Target
		for k, v := range x {
			if s, ok := v.(string); ok {
				o = append(o, model.Target{Name: k, Ecosystem: model.Node, Path: filepath.Join(root, s), Kind: "node-bin", Score: 100})
			}
		}
		return o
	}
	return []model.Target{{Name: name, Ecosystem: model.Node, Path: root, Kind: "node-package", Score: 70}}
}
func rubyTargets(root, name string) []model.Target {
	var o []model.Target
	candidates := []string{name, "beef"}
	seen := map[string]bool{}
	for _, n := range candidates {
		p := filepath.Join(root, n)
		if seen[n] {
			continue
		}
		seen[n] = true
		if i, e := os.Stat(p); e == nil && !i.IsDir() && i.Mode()&0111 != 0 {
			o = append(o, model.Target{Name: n, Ecosystem: model.Ruby, Path: p, Kind: "ruby-executable", Score: 120})
		}
	}
	m, _ := filepath.Glob(filepath.Join(root, "*.rb"))
	for _, p := range m {
		o = append(o, model.Target{Name: strings.TrimSuffix(filepath.Base(p), ".rb"), Ecosystem: model.Ruby, Path: p, Kind: "ruby-script", Score: 90})
	}
	if len(o) == 0 && fileExists(filepath.Join(root, "Rakefile")) {
		o = append(o, model.Target{Name: name, Ecosystem: model.Ruby, Path: root, Kind: "ruby-project", Score: 60})
	}
	return o
}
func cTargets(root, name string, e model.Ecosystem) []model.Target {
	b, _ := os.ReadFile(filepath.Join(root, "CMakeLists.txt"))
	re := regexp.MustCompile(`(?m)add_executable\s*\(\s*([A-Za-z0-9_.+-]+)`)
	m := re.FindAllStringSubmatch(string(b), -1)
	var o []model.Target
	for _, x := range m {
		o = append(o, model.Target{Name: x[1], Ecosystem: e, Path: root, Kind: "cmake-executable", Score: 100})
	}
	if len(o) > 0 {
		return o
	}
	return []model.Target{{Name: name, Ecosystem: e, Path: root, Kind: "native-project", Score: 50}}
}
func scriptTargets(root string, e model.Ecosystem, pat string) []model.Target {
	m, _ := filepath.Glob(filepath.Join(root, pat))
	var o []model.Target
	for _, p := range m {
		o = append(o, model.Target{Name: strings.TrimSuffix(filepath.Base(p), filepath.Ext(p)), Ecosystem: e, Path: p, Kind: "script", Score: 80})
	}
	return o
}
func fileExists(p string) bool { _, e := os.Stat(p); return e == nil }
