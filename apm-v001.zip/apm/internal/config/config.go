package config

import "path/filepath"

type Config struct{ Root, LinkDir string }

func Defaults(root, link string) Config { return Config{Root: root, LinkDir: link} }
func Package(root, name string) string  { return filepath.Join(root, "packages", name) }
