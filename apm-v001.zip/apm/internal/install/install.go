package install

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/apm-project/apm/internal/build"
	"github.com/apm-project/apm/internal/config"
	"github.com/apm-project/apm/internal/debug"
	"github.com/apm-project/apm/internal/detect"
	"github.com/apm-project/apm/internal/env"
	"github.com/apm-project/apm/internal/link"
	"github.com/apm-project/apm/internal/lock"
	"github.com/apm-project/apm/internal/model"
	"github.com/apm-project/apm/internal/resolve"
	"github.com/apm-project/apm/internal/workspace"
)

type metadata struct {
	URL  string `json:"url"`
	Name string `json:"name"`
}

func Install(c config.Config, url string, multi, dbg bool, override *resolve.Recipe) error {
	l := &debug.Logger{Enabled: dbg, W: os.Stderr}
	if err := workspace.Ensure(c.Root); err != nil {
		return err
	}
	name := workspace.Name(url)
	if err := os.MkdirAll(filepath.Join(c.Root, "locks"), 0755); err != nil {
		return err
	}
	lk, err := lock.Acquire(filepath.Join(c.Root, "locks", name+".lock"))
	if err != nil {
		return fmt.Errorf("lock %s: %w", name, err)
	}
	defer lk.Close()
	final := config.Package(c.Root, name)
	stage := final + ".installing"
	backup := final + ".old"
	_ = os.RemoveAll(stage)
	_ = os.RemoveAll(backup)
	if err := os.MkdirAll(stage, 0755); err != nil {
		return err
	}
	defer os.RemoveAll(stage)

	src := filepath.Join(stage, "source")
	l.Printf("source=%s", url)
	if err := workspace.Clone(url, src); err != nil {
		return fmt.Errorf("clone: %w", err)
	}
	detections := detect.Detect(src, name, l)
	if len(detections) == 0 {
		return fmt.Errorf("no supported build system detected")
	}
	recipe, err := resolve.Load(src)
	if err != nil {
		return err
	}
	if override != nil {
		recipe = override
	}
	primary, err := choosePrimary(detections, recipe)
	if err != nil {
		return err
	}
	l.Printf("primary ecosystem: %s", primary.Ecosystem)

	envs := []model.Ecosystem{primary.Ecosystem}
	if multi {
		envs = uniqueEcosystems(detections)
		l.Printf("--multivenv: preparing %d ecosystems", len(envs))
	}
	if err := env.Prepare(stage, envs, l); err != nil {
		return err
	}

	targets, err := resolve.ResolveWithRecipe(src, name, []model.Detection{primary}, l, recipe)
	if err != nil {
		return err
	}
	res, err := build.Build(src, stage, filepath.Join(stage, "bin"), targets, l)
	if err != nil {
		return err
	}
	if len(res.Artifacts) == 0 {
		return fmt.Errorf("no artifacts produced")
	}

	mb, _ := json.MarshalIndent(metadata{URL: url, Name: name}, "", "  ")
	if err := os.WriteFile(filepath.Join(stage, "metadata.json"), mb, 0644); err != nil {
		return err
	}
	if override != nil {
		rb, _ := json.MarshalIndent(override, "", "  ")
		if err := os.WriteFile(filepath.Join(stage, "apm.config.json"), rb, 0644); err != nil {
			return err
		}
	} else {
		if b, e := os.ReadFile(filepath.Join(src, "apm.json")); e == nil {
			_ = os.WriteFile(filepath.Join(stage, "apm.config.json"), b, 0644)
		}
	}

	// Critical lifecycle invariant: commit first, then create public links.
	// No link is ever allowed to contain .installing.
	l.Printf("committing %s -> %s", stage, final)
	type oldLink struct {
		name, target string
		exists       bool
	}
	var oldLinks []oldLink
	oldNames := map[string]bool{}
	if entries, e := os.ReadDir(filepath.Join(final, "bin")); e == nil {
		for _, entry := range entries {
			if !entry.IsDir() {
				oldNames[entry.Name()] = true
			}
		}
	}
	for _, a := range res.Artifacts {
		if a.Name == "" || a.Name == "." || a.Name == ".." || filepath.Base(a.Name) != a.Name || filepath.IsAbs(a.Name) {
			return fmt.Errorf("invalid executable name: %q", a.Name)
		}
		p := filepath.Join(c.LinkDir, a.Name)
		st, e := os.Lstat(p)
		if e == nil && st.Mode()&os.ModeSymlink == 0 {
			return fmt.Errorf("link path already exists and is not a symlink: %s", p)
		}
		t, re := os.Readlink(p)
		oldLinks = append(oldLinks, oldLink{a.Name, t, re == nil})
	}
	// Capture links belonging to the old package as well, so a reconfigure/update
	// that changes executable names can remove stale public links transactionally.
	for n := range oldNames {
		seen := false
		for _, a := range res.Artifacts {
			if a.Name == n {
				seen = true
				break
			}
		}
		if seen {
			continue
		}
		p := filepath.Join(c.LinkDir, n)
		if t, e := os.Readlink(p); e == nil {
			oldLinks = append(oldLinks, oldLink{n, t, true})
		}
	}
	if _, err := os.Stat(final); err == nil {
		if err = os.Rename(final, backup); err != nil {
			return err
		}
	}
	if err := os.Rename(stage, final); err != nil {
		if _, e := os.Stat(backup); e == nil {
			_ = os.Rename(backup, final)
		}
		return err
	}

	rollback := func() {
		_ = os.RemoveAll(final)
		if _, e := os.Stat(backup); e == nil {
			_ = os.Rename(backup, final)
		}
		for _, ol := range oldLinks {
			p := filepath.Join(c.LinkDir, ol.name)
			_ = os.Remove(p)
			if ol.exists {
				_ = os.Symlink(ol.target, p)
			}
		}
	}
	for _, a := range res.Artifacts {
		target := filepath.Join(final, "bin", a.Name)
		l.Printf("final artifact: %s", target)
		if filepath.Base(target) != a.Name {
			return rollbackAndError(rollback, fmt.Errorf("artifact/name mismatch: %s", target))
		}
		if err := link.Link(c.LinkDir, a.Name, target); err != nil {
			return rollbackAndError(rollback, fmt.Errorf("link %s: %w", a.Name, err))
		}
		l.Printf("symlink: %s -> %s", filepath.Join(c.LinkDir, a.Name), target)
	}
	newNames := map[string]bool{}
	for _, a := range res.Artifacts {
		newNames[a.Name] = true
	}
	for n := range oldNames {
		if newNames[n] {
			continue
		}
		p := filepath.Join(c.LinkDir, n)
		if target, e := os.Readlink(p); e == nil {
			oldPrefix := filepath.Clean(final) + string(filepath.Separator)
			if filepath.Clean(target) == filepath.Clean(final) || strings.HasPrefix(filepath.Clean(target), oldPrefix) {
				_ = os.Remove(p)
			}
		}
	}
	_ = os.RemoveAll(backup)
	return nil
}

func choosePrimary(d []model.Detection, r *resolve.Recipe) (model.Detection, error) {
	if r != nil && r.Build.System != "" {
		for _, x := range d {
			if string(x.Ecosystem) == r.Build.System {
				return x, nil
			}
		}
		return model.Detection{}, fmt.Errorf("apm.json selects unsupported build system: %s", r.Build.System)
	}
	best := d[0]
	for _, x := range d[1:] {
		if x.Score > best.Score {
			best = x
		}
	}
	return best, nil
}
func uniqueEcosystems(d []model.Detection) []model.Ecosystem {
	m := map[model.Ecosystem]bool{}
	var out []model.Ecosystem
	for _, x := range d {
		if !m[x.Ecosystem] {
			m[x.Ecosystem] = true
			out = append(out, x.Ecosystem)
		}
	}
	return out
}
func rollbackAndError(fn func(), err error) error { fn(); return err }

func Update(c config.Config, name string, dbg bool) error {
	b, err := os.ReadFile(filepath.Join(config.Package(c.Root, name), "metadata.json"))
	if err != nil {
		return fmt.Errorf("no metadata for %s: %w", name, err)
	}
	var m metadata
	if err = json.Unmarshal(b, &m); err != nil || m.URL == "" {
		return fmt.Errorf("invalid metadata for %s", name)
	}
	var recipe *resolve.Recipe
	if b, e := os.ReadFile(filepath.Join(config.Package(c.Root, name), "apm.config.json")); e == nil {
		var r resolve.Recipe
		if json.Unmarshal(b, &r) == nil {
			recipe = &r
		}
	}
	return Install(c, m.URL, false, dbg, recipe)
}
