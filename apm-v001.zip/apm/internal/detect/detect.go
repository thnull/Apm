package detect

import (
	"github.com/apm-project/apm/internal/debug"
	"github.com/apm-project/apm/internal/model"
	"os"
	"path/filepath"
	"strings"
)

func exists(r, n string) bool { _, e := os.Stat(filepath.Join(r, n)); return e == nil }
func glob(r, p string) bool   { m, _ := filepath.Glob(filepath.Join(r, p)); return len(m) > 0 }
func Detect(root, projectName string, l *debug.Logger) []model.Detection {
	var d []model.Detection
	add := func(e model.Ecosystem, s int, ev ...string) {
		d = append(d, model.Detection{Ecosystem: e, Score: s, Evidence: ev})
	}
	if exists(root, "go.mod") {
		add(model.Go, 100, "go.mod")
	}
	if exists(root, "Cargo.toml") {
		add(model.Rust, 100, "Cargo.toml")
	}
	if exists(root, "pyproject.toml") {
		add(model.Python, 100, "pyproject.toml")
	} else if exists(root, "setup.py") || exists(root, "setup.cfg") {
		add(model.Python, 90, "Python metadata")
	} else if exists(root, "requirements.txt") {
		add(model.Python, 70, "requirements.txt")
	} else {
		// Many security tools are intentionally distributed as a single
		// top-level script (for example sqlmap.py). Treat an exact
		// <repository-name>.py match as high-confidence Python evidence,
		// while avoiding generic *.py detection.
		entries, _ := os.ReadDir(root)
		for _, e := range entries {
			if !e.IsDir() && e.Name() == projectName+".py" {
				add(model.Python, 85, e.Name())
				break
			}
		}
	}
	if exists(root, "Gemfile") || glob(root, "*.gemspec") {
		add(model.Ruby, 100, "Ruby metadata")
	}
	if exists(root, "pom.xml") || exists(root, "build.gradle") || exists(root, "build.gradle.kts") || exists(root, "gradlew") {
		add(model.Java, 100, "JVM metadata")
	}
	if exists(root, "CMakeLists.txt") {
		add(model.Cpp, 95, "CMakeLists.txt")
	}
	if exists(root, "meson.build") {
		add(model.Cpp, 90, "meson.build")
	}
	if exists(root, "configure.ac") || exists(root, "configure.in") {
		add(model.C, 90, "Autotools metadata")
	}
	if exists(root, "Makefile") || exists(root, "makefile") {
		add(model.Cpp, 50, "Makefile")
	}
	if exists(root, "package.json") {
		add(model.Node, 100, "package.json")
	}
	if glob(root, "*.csproj") || glob(root, "*.sln") {
		add(model.DotNet, 100, ".NET metadata")
	}
	if exists(root, "composer.json") {
		add(model.PHP, 100, "composer.json")
	}
	if exists(root, "cpanfile") || exists(root, "Makefile.PL") {
		add(model.Perl, 100, "Perl metadata")
	}
	for _, x := range d {
		l.Printf("detected %-7s score=%d evidence=%s", x.Ecosystem, x.Score, strings.Join(x.Evidence, ", "))
	}
	return d
}
