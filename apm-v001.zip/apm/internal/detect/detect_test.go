package detect

import (
	"github.com/apm-project/apm/internal/debug"
	"os"
	"path/filepath"
	"testing"
)

func touch(t *testing.T, p string) {
	t.Helper()
	if err := os.WriteFile(p, []byte(""), 0644); err != nil {
		t.Fatal(err)
	}
}
func TestKnownBuildSystems(t *testing.T) {
	cases := []struct{ name, file string }{{"go", "go.mod"}, {"rust", "Cargo.toml"}, {"python", "pyproject.toml"}, {"ruby", "Gemfile"}, {"java", "pom.xml"}, {"cmake", "CMakeLists.txt"}, {"node", "package.json"}, {"dotnet", "x.csproj"}, {"php", "composer.json"}, {"perl", "cpanfile"}}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			d := t.TempDir()
			touch(t, filepath.Join(d, tc.file))
			got := Detect(d, tc.name, &debug.Logger{})
			if len(got) == 0 {
				t.Fatalf("no detection for %s", tc.name)
			}
		})
	}
}

func TestSingleFilePythonUsesProjectName(t *testing.T) {
	d := t.TempDir()
	if err := os.WriteFile(filepath.Join(d, "sqlmap.py"), []byte("print(1)\n"), 0755); err != nil {
		t.Fatal(err)
	}
	got := Detect(d, "sqlmap", &debug.Logger{})
	if len(got) != 1 || got[0].Ecosystem != "python" {
		t.Fatalf("expected python detection, got %#v", got)
	}
}
