# APM v10 — Advanced Package Manager

APM installs Git repositories as isolated, globally callable tools without modifying `.bashrc` and without requiring `source venv/bin/activate`.

## Architecture

```text
Git repository
    ↓
Detector
    ↓
Primary ecosystem + optional multi-environment plan
    ↓
Target resolver
    ↓
Isolated environment provider
    ↓
Build provider registry
    ↓
Artifact resolver
    ↓
Transactional commit
    ↓
Public symlink
```

The public symlink is created **only after** `.installing` has been renamed to its final package directory. Therefore a link such as:

```text
/usr/local/bin/httpx -> /opt/apm/packages/httpx.installing/bin/httpx
```

is treated as a lifecycle bug and is explicitly tested against.

## Supported families

Detection/resolution/build providers cover:

- Go modules
- Rust/Cargo
- Python / venv / pip
- Ruby / Bundler
- Node.js / npm
- Java / Maven / Gradle
- C/C++ / CMake / Make
- Autotools
- Meson (when `meson` is installed)
- .NET
- PHP / Composer-aware environment variables
- Perl

APM deliberately does **not** promise to guess arbitrary repositories. If a repository has several plausible executables, use `apm.json`:

```json
{
  "build": {
    "system": "go",
    "target": "./cmd/httpx"
  },
  "executables": ["httpx"]
}
```

## Manual target configuration

APM can be told exactly which source target should become which public executable. This is useful when auto-detection finds multiple candidates or when a repository uses a non-standard layout.

For an already installed tool:

```bash
apm configure ambiguous --build-system go \
  --target ./cmd/client --executable client
```

Multiple executables are supported by repeating the pair:

```bash
apm configure multi --build-system node \
  --target ./client.js --executable client \
  --target ./server.js --executable server
```

`configure` validates the targets, persists the recipe as `apm.config.json`, and performs a transactional update. The configuration is therefore reused by future `apm update` operations.

The same manual recipe can be supplied during a fresh install:

```bash
apm install --build-system go \
  --target ./cmd/tool --executable tool \
  https://github.com/example/tool.git
```

Precedence is:

```text
CLI manual recipe
      ↓
user apm.config.json (installed package)
      ↓
repository apm.json
      ↓
auto detection
```

A target must stay inside the checked-out source tree and executable names cannot contain path components. Ambiguous projects fail rather than silently selecting an arbitrary executable.

## Install

```bash
sudo apm install https://github.com/projectdiscovery/httpx.git
```

Flags may appear before or after the repository URL:

```bash
sudo apm install --debug https://github.com/projectdiscovery/httpx.git
sudo apm install https://github.com/projectdiscovery/httpx.git --debug
sudo apm install --multivenv https://github.com/example/tool.git
sudo apm install https://github.com/example/tool.git --install-path /opt/my-apm
```

Default layout:

```text
/opt/apm/packages/httpx/
├── source/
├── environment/
│   └── go/
└── bin/
    └── httpx
```

Public command:

```text
/usr/local/bin/httpx -> /opt/apm/packages/httpx/bin/httpx
```

No shell startup file is modified.

## Isolation model

Isolation is the default; it is not an optional post-install step.

Examples:

```text
packages/sqlmap/environment/python/venv/
packages/httpx/environment/go/gomodcache/
packages/beef/environment/ruby/bundle/
packages/tool/environment/node/prefix/
```

System compilers/interpreters are reused as toolchains, but dependency state and relevant caches are kept per package. For example, Go gets an APM-shared compiler `GOCACHE` (safe content-addressed build cache) while `GOMODCACHE` and `GOPATH` stay package-local; npm gets a package-local prefix/cache; Python gets a package-local venv and pip cache.

### Multi-runtime repositories

```bash
apm install --multivenv https://github.com/example/mixed-tool.git
```

`--multivenv` prepares environments for every detected ecosystem, while the build still uses one primary ecosystem/target. This prevents a Go + Python repository from accidentally producing two artifacts with the same command name.

### Manual environment creation

After a tool is installed:

```bash
apm env create httpx --go
apm env create sqlmap --python
apm env create beef --ruby
```

Without an explicit ecosystem flag, APM infers the environments from the installed source tree.

## BeEF-shaped repositories

A repository such as BeEF is a useful multi-runtime case: Ruby/Bundler is the primary runtime while Node.js metadata is also present. APM resolves the executable named `beef` even though the upstream executable is not necessarily named `beef.rb`.

The important design choice is that APM does not blindly execute an upstream `./install` script if that script is capable of changing the host OS. Instead, the Ruby provider keeps Bundler state under the package environment and generates a relocatable launcher.

## Go target resolution

APM does not select the first `main.go` it finds.

For a repository such as:

```text
cmd/httpx/main.go
cmd/functional-test/main.go
```

`go list ./...` identifies both main packages. APM chooses the exact tool/package name when it is unambiguous; otherwise installation fails and asks for `apm.json` instead of silently installing the wrong binary.

## Update

```bash
sudo apm update httpx
sudo apm update httpx --debug
```

Update is transactional:

```text
old package
   ↓
new .installing package
   ↓
detect → resolve → fresh environment → build → validate
   ↓
commit
   ↓
re-point public symlink
```

If the new build fails, the old package and old symlink remain usable.

## Debug mode

```bash
apm install https://github.com/projectdiscovery/httpx.git --debug
```

Debug output includes detection, selected ecosystem, target, environment, build command, artifact and final symlink path. A healthy final sequence looks like:

```text
[debug] final artifact: /opt/apm/packages/httpx/bin/httpx
[debug] symlink: /usr/local/bin/httpx -> /opt/apm/packages/httpx/bin/httpx
```

## Tests

The repository includes unit tests and an integration suite covering:

- Go multi-target resolution (`httpx` vs helper binaries)
- true ambiguity failures
- Python venv and relocatable launchers
- Node/npm local environment
- CMake/C build
- Ruby/Bundler
- BeEF-shaped Ruby + Node repository
- PHP and Perl script providers
- multi-ecosystem `--multivenv`
- `apm env create`
- exact post-commit symlink target
- rejection of `.installing` symlinks
- failed update rollback
- update symlink correctness
- `--debug` after the URL

Run:

```bash
go test ./...
go test -race ./...
go vet ./...
bash tests/integration.sh
```

For an actual network-backed upstream repository, network availability and its external dependency servers are additional variables; the integration suite uses deterministic local fixtures so failures in APM itself are distinguishable from network failures.
